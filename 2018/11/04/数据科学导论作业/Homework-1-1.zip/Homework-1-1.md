
# Homework 1-0
1、False  False  False  True  True

2、（2）（3）（4）

3、（2）

4、（2）

5、 B  B

6、  
(1) print(df.Name.value_counts().count())  
(2) print( df.sort_values(by='Age',ascending=False).iloc[0,3] )  
(3) print( df.Fur.value_counts().index[0] )  
(4) print('percent: {:.2%}'.format(df.Fur.value_counts()[0]/df.Fur.value_counts().sum()))
    

# Homework 1-1

---

Welcome to Data Science Course. To ensure everything goes smoothly moving forward, we will setup the majority of those tools in this homework. While some of this will likely be dull, doing it now will enable us to do more exciting work in the weeks that follow without getting bogged down in further software configuration. 


## Programming expectations

All the homework for this class will use Python and, for the most part, the browser-based Jupyter notebook format you are currently viewing. Knowledge of Python is not a prerequisite for this course, **provided you are comfortable learning on your own as needed**. While we have strived to make the programming component of this course straightforward, we will not devote much time to teaching prorgramming or Python syntax. Basically, you should feel comfortable with:

* How to look up Python syntax on Google and StackOverflow.
* Basic programming concepts like functions, loops, arrays, dictionaries, strings, and if statements.
* How to learn new libraries by reading documentation.
* Asking questions on StackOverflow or Google.

There are many online tutorials to introduce you to scientific python programming.

## Getting Python

You will be using Python throughout the course, including many popular 3rd party Python libraries for scientific computing. Anaconda is an easy-to-install bundle of Python and most of these libraries. We recommend that you use Anaconda for this course.


## Hello, Python

The Jupyter notebook is an application to build interactive computational notebooks. You'll be using them to complete homework. Once you've set up Python, please open this page(*.ipynb) with Jupyter notebook, by running anaconda navigator and Jupyter notebook.

Notebooks are composed of many "cells", which can contain text (like this one), or code (like the one below). Double click on the cell below, and evaluate it by clicking the "Run" button above.


```python
x = [10, 20, 30, 40, 50]
for item in x:
    print("Item is ", item) 
```

    Item is  10
    Item is  20
    Item is  30
    Item is  40
    Item is  50
    

## Python Libraries

We will be using a several different libraries throughout this course. If you've successfully completed the installation instructions, all of the following statements should run.


```python

# Numpy is a library for working with Arrays
import numpy as np
print("Numpy version:  %6.6s " % np.__version__) 

# SciPy implements many different numerical algorithms
import scipy as sp
print("SciPy version:  %6.6s " % sp.__version__) 

# Pandas makes working with data tables easier
import pandas as pd
print("Pandas version:  %6.6s" % pd.__version__) 

# Module for plotting
import matplotlib
print("Mapltolib version:  %6.6s" % matplotlib.__version__) 

# SciKit Learn implements several Machine Learning algorithms
import sklearn
print("Scikit-Learn version: %6.6s " % sklearn.__version__) 

# Requests is a library for getting data from the Web
import requests
print("requests version:     %6.6s" % requests.__version__) 

# Networkx is a library for working with networks
import networkx as nx
print("NetworkX version:     %6.6s " % nx.__version__) 

#BeautifulSoup is a library to parse HTML and XML documents
import bs4
from bs4 import BeautifulSoup
print("BeautifulSoup4 version:%6.6s " % bs4.__version__) 


```

    Numpy version:  1.15.3 
    SciPy version:   1.1.0 
    Pandas version:  0.23.4
    Mapltolib version:   3.0.1
    Scikit-Learn version: 0.20.0 
    requests version:     2.20.0
    NetworkX version:        2.2 
    BeautifulSoup4 version: 4.6.3 
    

If any of these libraries are missing or out of date, you will need to install them.and restart Jupyter notebook.

## Hello matplotlib

The notebook integrates nicely with Matplotlib, the primary plotting package for python. This should embed a figure of a sine wave:


```python
# this actually imports matplotlib
import matplotlib.pyplot as plt  

x = np.linspace(0, 10, 30)  #array of 30 points from 0 to 10
y = np.sin(x)
z = y + np.random.normal(size=30) * .2
plt.plot(x, y, 'ro-', label='A sine wave')
plt.plot(x, z, 'b-', label='Noisy sine')
plt.legend(loc = 'lower right')
plt.xlabel("X axis")
plt.ylabel("Y axis")           
```




    Text(0, 0.5, 'Y axis')





## Hello Numpy

The Numpy array processing library is the basis of nearly all numerical computing in Python. Here's a 30 second crash course. For more details, consult the [Numpy User's Guide](http://docs.scipy.org/doc/numpy-dev/user/index.html)


```python
print("Make a 3 row x 4 column array of random numbers") 
x = np.random.random((3, 4))
print(x)
print("\n")

print("Add 1 to every element") 
x = x + 1
print(x)
print("\n")

print("Get the element at row 1, column 2") 
print(x[1, 2]) 
print("\n")

# The colon syntax is called "slicing" the array. 
print("Get the first row") 
print(x[0, :]) 
print("\n")

print("Get every 2nd column of the first row") 
print(x[0, ::2]) 
print("\n")
```

    Make a 3 row x 4 column array of random numbers
    [[0.77019563 0.47066057 0.78436526 0.32801454]
     [0.010611   0.2097674  0.33848544 0.42230589]
     [0.05992949 0.81801877 0.924347   0.69506907]]
    
    
    Add 1 to every element
    [[1.77019563 1.47066057 1.78436526 1.32801454]
     [1.010611   1.2097674  1.33848544 1.42230589]
     [1.05992949 1.81801877 1.924347   1.69506907]]
    
    
    Get the element at row 1, column 2
    1.338485436839295
    
    
    Get the first row
    [1.77019563 1.47066057 1.78436526 1.32801454]
    
    
    Get every 2nd column of the first row
    [1.77019563 1.78436526]
    
    
    

Print the maximum, minimum, and mean of the array. This does **not** require writing a loop. In the code cell below, type `x.m<TAB>`, to find built-in operations for common array statistics like this


```python
#your code here
print(x.max())
print(x.min())
print(x.mean())
```

    1.9243469995684759
    1.0106109950203765
    1.485980839120101
    

Call the `x.max` function again, but use the `axis` keyword to print the maximum of each row in x.


```python
#your code here
print( x.max(axis=1) )
```

    [1.78436526 1.42230589 1.924347  ]
    

Here's a way to quickly simulate 500 coin "fair" coin tosses (where the probabily of getting Heads is 50%, or 0.5)


```python
x = np.random.binomial(500, .5)
print("number of heads:", x) 
```

    number of heads: 253
    

Repeat this simulation 500 times, and use the [plt.hist() function](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.hist) to plot a histogram of the number of Heads (1s) in each simulation


```python
#your code here
data = []
for i in range(1,500):
    data.append(np.random.binomial(500,.5))
plt.hist(data, bins=40, facecolor="blue", edgecolor="black", alpha=0.7)
# 显示横轴标签
plt.xlabel("number of Heads")
# 显示纵轴标签 
plt.ylabel("频数") 
# 显示图标题 
plt.title("频数分布直方图")
```




    Text(0.5, 1.0, '频数分布直方图')




![png](output_19_1.png)


## The Monty Hall Problem


Here's a fun and perhaps surprising statistical riddle, and a good way to get some practice writing python functions

In a gameshow, contestants try to guess which of 3 closed doors contain a cash prize (goats are behind the other two doors). Of course, the odds of choosing the correct door are 1 in 3. As a twist, the host of the show occasionally opens a door after a contestant makes his or her choice. This door is always one of the two the contestant did not pick, and is also always one of the goat doors (note that it is always possible to do this, since there are two goat doors). At this point, the contestant has the option of keeping his or her original choice, or swtiching to the other unopened door. The question is: is there any benefit to switching doors? The answer surprises many people who haven't heard the question before.

We can answer the problem by running simulations in Python. We'll do it in several parts.

First, write a function called `simulate_prizedoor`. This function will simulate the location of the prize in many games -- see the detailed specification below:


```python
"""
Function
--------
simulate_prizedoor

Generate a random array of 0s, 1s, and 2s, representing
hiding a prize between door 0, door 1, and door 2

Parameters
----------
nsim : int
    The number of simulations to run

Returns
-------
sims : array
    Random array of 0s, 1s, and 2s

Example
-------
>>> print simulate_prizedoor(3)
array([0, 0, 2])
"""
def simulate_prizedoor(nsim):
    answer = np.random.randint(0,3,nsim)
    return answer
#your code here
print(simulate_prizedoor(5))
```

    [1 0 0 0 1]
    

Next, write a function that simulates the contestant's guesses for `nsim` simulations. Call this function `simulate_guess`. The specs:


```python
"""
Function
--------
simulate_guess

Return any strategy for guessing which door a prize is behind. This
could be a random strategy, one that always guesses 2, whatever.

Parameters
----------
nsim : int
    The number of simulations to generate guesses for

Returns
-------
guesses : array
    An array of guesses. Each guess is a 0, 1, or 2

Example
-------
>>> print simulate_guess(5)
array([0, 0, 0, 0, 0])
"""
#your code here
def simulate_guess(nsim):
    answer = np.random.randint(0,3,nsim)
    return answer
print(simulate_guess(5))

```

    [1 0 2 0 2]
    

Next, write a function, `goat_door`, to simulate randomly revealing one of the goat doors that a contestant didn't pick.


```python
"""
Function
--------
goat_door

Simulate the opening of a "goat door" that doesn't contain the prize,
and is different from the contestants guess

Parameters
----------
prizedoors : array
    The door that the prize is behind in each simulation
guesses : array
    THe door that the contestant guessed in each simulation

Returns
-------
goats : array
    The goat door that is opened for each simulation. Each item is 0, 1, or 2, and is different
    from both prizedoors and guesses

Examples
--------
>>> print goat_door(np.array([0, 1, 2]), np.array([1, 1, 1]))
>>> array([2, 2, 0])
"""
#your code here
def goat_door(prizedoors,guesses):
    import random
    nsim = prizedoors.size
    answer = []
    for i in range(0,nsim):
        if( prizedoors[i]!=guesses[i] ):
            answer.append(3-prizedoors[i]-guesses[i])
        elif( prizedoors[i]==0 ):
            answer.append( random.choice([1,2]) )
        elif( prizedoors[i]==1 ):
            answer.append( random.choice([0,2]) )
        else:
            answer.append( random.choice([0,1]) )
    return np.array(answer)

prizedoor = simulate_prizedoor(5)
print( "prizedoor:  ",prizedoor )
guess = simulate_guess(5)
print( "guess:  ",guess )
goat = goat_door( prizedoor, guess )
print( "goat:  ",goat )

```

    prizedoor:   [1 0 1 0 0]
    guess:   [0 1 1 1 1]
    goat:   [2 2 0 2 2]
    

Write a function, `switch_guess`, that represents the strategy of always switching a guess after the goat door is opened.


```python
"""
Function
--------
switch_guess

The strategy that always switches a guess after the goat door is opened

Parameters
----------
guesses : array
     Array of original guesses, for each simulation
goatdoors : array
     Array of revealed goat doors for each simulation

Returns
-------
The new door after switching. Should be different from both guesses and goatdoors

Examples
--------
>>> print switch_guess(np.array([0, 1, 2]), np.array([1, 2, 1]))
>>> array([2, 0, 0])
"""
#your code here
def switch_guess( guesses, goatdoors ):
    answer = []
    nsim = guesses.size
    for i in range(0,nsim):
        answer.append(3-guesses[i]-goatdoors[i])
    return np.array(answer)
#奖品实际位置
prizedoor = simulate_prizedoor(5)
print( "prizedoor:  ",prizedoor )
#猜测奖品的位置
guesses = simulate_guess(5)
print("guesses:  ",guesses)
#主持人打开的羊所在的位置
goatdoors = goat_door( prizedoor,guesses )
print("goatdoors:  ",goatdoors)
#改变选择后所选的位置
switchguess = switch_guess(guesses,goatdoors)
print("switchguess:  ",switchguess)
```

    prizedoor:   [1 2 0 2 2]
    guesses:   [2 0 0 2 0]
    goatdoors:   [0 1 1 0 1]
    switchguess:   [1 2 2 1 2]
    

Last function: write a `win_percentage` function that takes an array of `guesses` and `prizedoors`, and returns the percent of correct guesses


```python
"""
Function
--------
win_percentage

Calculate the percent of times that a simulation of guesses is correct

Parameters
-----------
guesses : array
    Guesses for each simulation
prizedoors : array
    Location of prize for each simulation

Returns
--------
percentage : number between 0 and 100
    The win percentage

Examples
---------
>>> print win_percentage(np.array([0, 1, 2]), np.array([0, 0, 0]))
33.333
"""
#your code here
def win_percentage(guesses,prizedoor):
    nsim = guesses.size
    correct = 0
    for i in range(0,nsim):
        if( guesses[i]==prizedoor[i] ):
            correct += 1
    return round(100.0*correct/nsim,3)
```

Now, put it together. Simulate 10000 games where contestant keeps his original guess, and 10000 games where the contestant switches his door after a  goat door is revealed. Compute the percentage of time the contestant wins under either strategy. Is one strategy better than the other?


```python
#your code here
#奖品实际位置
prizedoor = simulate_prizedoor(10000)
#print( "prizedoor:  ",prizedoor )
#猜测奖品的位置
guesses = simulate_guess(10000)
#print("guesses:  ",guesses)
#主持人打开的羊所在的位置
goatdoors = goat_door( prizedoor,guesses )
#print("goatdoors:  ",goatdoors)
#改变选择后所选的位置
switchguess = switch_guess(guesses,goatdoors)
#print("switchguess:  ",switchguess)
#不改选择的准确率
print("不改选择的准确率：",win_percentage(guesses,prizedoor))
#改变选择的准确率
print("改变选择的准确率：",win_percentage(switchguess,prizedoor))
```

    不改选择的准确率： 34.12
    改变选择的准确率： 65.88
    

Many people find this answer counter-intuitive (famously, PhD mathematicians have incorrectly claimed the result must be wrong. Clearly, none of them knew Python). 

